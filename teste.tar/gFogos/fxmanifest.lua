fx_version 'adamant'
game 'gta5'

client_scripts {
	"@vrp/lib/utils.lua",
	"gFogos/gClient.lua"
}

server_scripts {
	'@vrp/lib/utils.lua',
	'config.lua',
	'gFogos/gServer.lua'
}
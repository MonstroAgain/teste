--Desenvolvido e corrigido pra vRPex por Guedes#0001 

local Proxy = module("vrp","lib/Proxy")
local gCfg = module("gFogos","config")

vRP = Proxy.getInterface("vRP")

local user_id = vRP.getUserId(source)

RegisterCommand(gCfg.cmdPlayer, function(source, args, rawCommand)
	local user_id = vRP.getUserId(source)
	if gCfg.usaritem then
		if vRP.tryGetInventoryItem(user_id,gCfg.item,1) then
			TriggerClientEvent('gFogosStart',source)
		end
	else
		TriggerClientEvent('gFogosStart',source)
	end
end)

if gCfg.usaritem then
	RegisterCommand(gCfg.cmdAdm, function(source, args, rawCommand)
		local user_id = vRP.getUserId(source)
		if vRP.hasPermission(user_id,gCfg.permAdm) then
			TriggerClientEvent('gFogosStart',source)
		end
	end)
end

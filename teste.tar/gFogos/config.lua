--Desenvolvido e corrigido pra vRPex por Guedes#0001 

local gCfg = {}

--SETAR COMANDO PARA PLAYER
gCfg.cmdPlayer = "fogos"

--SETAR COMANDO PARA ADM (SERVE PRA DAR O COMANDO SEM PRECISA DO ITEM)
gCfg.cmdAdm = "fogos2"

--ESCOLHA SE USA ITEM OU NÃO (SE FALSE, NÃO ATIVA O COMANDO DE ADM)
gCfg.usaritem = true

--SE USAR ITEM, ESCOLHA O NOME DO ITEM NA SUA BASE
gCfg.item = "fogos"

--ESCOLHE PERMISSÃO DE ADM
gCfg.permAdm = "admin.permissao"

return gCfg